<?php
return [
    'area_region'=>'大区名称',
    'area_name'=>'地区名称',
    'area_parentid'=>'上级地区',
    'area_sort'=>'排序',
    'area_name_error'=>'地区名称必填',
    'area_sort_error'=>'排序必须为0-255间数字',
    'add_child' =>'新增下级'
];