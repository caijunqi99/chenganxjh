<?php
$lang['default_goods_image'] = '默认商品图片:';
$lang['default_store_logo'] = '默认店铺标志:';
$lang['default_store_avatar'] = '默认店铺头像:';
$lang['default_user_portrait'] = '默认会员头像';
$lang['upload_type']  = '商品图片存储方式';
$lang['upload_type_local'] = '本地存储';
$lang['upload_type_oss'] ='OSS存储';
$lang['oss_accessid'] = 'OssAccessKeyId';
$lang['oss_accesssecret'] ='OssSecretAccess';
$lang['oss_bucket']='OssBucket';
$lang['oss_endpoint'] ='OssEndpoint';
$lang['endpoint_type'] ='OssEndpoint是否CNAME指向域名';