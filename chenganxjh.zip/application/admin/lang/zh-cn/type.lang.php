<?php

return [
    'type_id' => '类别ID',
    'type_name' => '类别名称',
    'type_sort' => '类别排序',
    'gc_id' => '分类ID',
    'gc_name' => '分类名称',
];
?>
