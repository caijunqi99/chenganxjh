<?php
return [
    'page_title'=>'文章分类',
    'ac_name'=>'分类名称',
    'ac_sort'=>'排序',
    'ac_parentid'=>'上级分类',
    'ac_name_error'=>'分类名称必填',
    'ac_sort_error'=>'排序只能为数字',
    'drop_child_error'=>'请先删除子分类',
    'add_child'=>'添加子分类'
];