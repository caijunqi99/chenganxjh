$(function(){
	var mySwiper = new Swiper('.swiper-container', {
		autoplay: 3000,
		speed: 1000,
		prevButton: '.swiper-button-prev',
    	nextButton: '.swiper-button-next',
		loop: true
	});
})
