var api = 'http://vip.xiangjianhai.com:8001/index.php/Wap';

var upload_url = 'http://vip.xiangjianhai.com:8001/uploads';
//获取cookie中存储的token,member_id

// 视频的url地址
var video_url = 'http://pgj4a41j8.bkt.clouddn.com/admin_video_20181101111008_1541041808.mp4'

// var user_token = $.cookie('token');
// var user_member_id = $.cookie('member_id');
var user_token = '74db5c057bf603370584ee935bd5e461';
var user_member_id = 10018;
