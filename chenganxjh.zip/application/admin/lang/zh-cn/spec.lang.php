<?php
return [
    'sp_id' => '规格ID',
    'sp_name' => '规格名称',
    'sp_sort' => '规格排序',
    'gc_id' => '分类ID',
    'gc_name' => '分类名称',
];
?>
