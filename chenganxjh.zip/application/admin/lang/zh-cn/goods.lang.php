<?php
return [
    'page_title' => '商品管理',
    'all_goods'=>'所有商品',
    'up_goods'=>'下架商品',
    'wait_goods'=>'待审核',
    'goods_common'=>'平台货号',
    'goods_name'=>'商品名称',
    'brand_cat'=>'分类&品牌',
    'price'=>'价格',
    'goods_storage'=>'库存',
    'goods_state'=>'商品状态',
    'goods_verify'=>'审核状态',
];