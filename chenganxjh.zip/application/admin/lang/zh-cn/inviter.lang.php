<?php

$lang['inviter_back']			= '推广背景图片';