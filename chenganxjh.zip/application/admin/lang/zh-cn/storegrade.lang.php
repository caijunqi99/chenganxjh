<?php

return [
    'sg_name'=>'等级名称',
    'sg_goods_limit'=>'可发布商品数',
    'sg_album_limit'=>'可上传图片数',
    'sg_space_limit'=>'可使用空间大小',
    'sg_template_number'=>'可选模板套数',
    'sg_template'=>'可选模板',
    'sg_price'=>'收费标准',
    'sg_confirm'=>'是否审核',
    'sg_description'=>'申请说明',
    'sg_function'=>'可用附加功能',
    'sg_sort'=>'等级级别',
    'store_grade_name' => '等级名称',
];
?>
